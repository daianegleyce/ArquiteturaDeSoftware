# ccp3an_mca_app_previsoes
Exercícios dos PDFs de Arquitetura de Software

João Victor Cardoso Domingues - 81712548
