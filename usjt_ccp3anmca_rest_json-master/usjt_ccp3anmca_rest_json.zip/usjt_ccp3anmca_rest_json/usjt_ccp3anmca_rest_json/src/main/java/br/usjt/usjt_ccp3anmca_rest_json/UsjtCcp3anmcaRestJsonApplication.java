package br.usjt.usjt_ccp3anmca_rest_json;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsjtCcp3anmcaRestJsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsjtCcp3anmcaRestJsonApplication.class, args);
	}

}
