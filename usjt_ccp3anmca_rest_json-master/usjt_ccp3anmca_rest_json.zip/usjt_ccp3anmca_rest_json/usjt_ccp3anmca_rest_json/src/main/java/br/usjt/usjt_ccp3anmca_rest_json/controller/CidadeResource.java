package br.usjt.usjt_ccp3anmca_rest_json.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.usjt.usjt_ccp3anmca_rest_json.model.Cidade;
import br.usjt.usjt_ccp3anmca_rest_json.repository.CidadeRepository;

@RestController
@RequestMapping("/cidades")
public class CidadeResource {

	@Autowired
	private CidadeRepository cidadeRep;

	// Listar todas as Cidades.
	@GetMapping("/listaCidade")
	public List<Cidade> todasCidades() {
		return cidadeRep.findAll();
	}

	// Listar todas as Cidades por letra inicial
	@GetMapping("/listaPorNome/{nomeCidade}")
	public List<Cidade> todasCidadesPorLetra(@PathVariable("nomeCidade") String nomeCidade ) {
		return cidadeRep.buscarPorLetra(nomeCidade);
	}

	// Obter uma cidade por sua latitude e longitude.
	@GetMapping("/listaPorLatLon/{latitude}/{longitude}")
	public List<Cidade> buscaPorLatitudeELongitude(@PathVariable("latitude") int latitude,
			@PathVariable("longitude") int longitude) {
		return cidadeRep.buscaPorLatitudeELongitude(latitude, longitude);
	}

	// Criando/Cadastrando nova Cidade
	@RequestMapping(value = "nova", method = RequestMethod.POST)
	// @PostMapping("/nova")
	public Cidade novaCidade(@RequestBody Cidade cidade) {
		return cidadeRep.save(cidade);
	}

}
