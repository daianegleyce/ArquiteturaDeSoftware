package br.usjt.usjt_ccp3anmca_rest_json.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.usjt.usjt_ccp3anmca_rest_json.model.Livro;

public interface LivroRepository extends JpaRepository <Livro, Long>{
	
}