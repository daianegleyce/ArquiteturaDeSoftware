package br.usjt.usjt_ccp3anmca_rest_json;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UsjtCcp3anmcaRestJsonApplicationTests {

	@Test
	public void contextLoads() {
	}

}
